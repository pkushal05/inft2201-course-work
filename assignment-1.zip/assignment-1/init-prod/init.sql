DROP TABLE IF EXISTS mail;

CREATE TABLE mail (
    id SERIAL PRIMARY KEY,
    subject TEXT NOT NULL,
    body TEXT NOT NULL
);